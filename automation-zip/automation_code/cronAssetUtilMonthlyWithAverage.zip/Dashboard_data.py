import pandas as pd
import config
from sqlalchemy import create_engine
from sqlalchemy.sql import text
import numpy as np
import calendar

def file_process(event):
    engine = create_engine('%s://%s:%s@%s:%s/%s' % (config.db_driver, config.db_user, config.db_pass, config.db_host, config.db_port, config.db_name))
    conn = engine.connect()
    nulldata = 'null'
    #q = 'select "MachineNumber", "Date", "MonthlyAssetUtil" From iss_usage_2012_q1 WHERE "MonthlyAssetUtil" is null LIMIT 1000'
    q1 = 'SELECT Distinct(EXTRACT(YEAR FROM "Date")) as "year" FROM "Intellitrail_raw" WHERE "MonthlyAssetUtil" = \''+str(nulldata)+'\''
    yearData = pd.read_sql(q1, con=engine)
    print "year"
    for year in yearData['year']:
        q2 = 'SELECT Distinct("MachineNumber") FROM "Intellitrail_raw" WHERE "MonthlyAssetUtil" = \''+str(nulldata)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\''
        uniqueMachine = pd.read_sql(q2, con=engine)
        print "machine data"
        for machineNum in uniqueMachine['MachineNumber']:
            for i in range(1,13):
                totalNumberOfDaysInMonth = 0
                q3 = 'SELECT count(Distinct("Date")) as "numberOfDaysRan" FROM "Intellitrail_raw" WHERE "MachineNumber" = \''+str(machineNum)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\' AND EXTRACT(MONTH FROM "Date") = \''+str(int(i))+'\''
                numberOfDaysRan = pd.read_sql(q3, con=engine)
                totalNumberOfDaysInMonth = calendar.monthrange(int(year),i)[1]
                assutUtData = 0.00
                assutUtData = float(numberOfDaysRan['numberOfDaysRan'][0])/float(totalNumberOfDaysInMonth)
                stringSql = ''
                stringSql = text('UPDATE "Intellitrail_raw" SET "MonthlyAssetUtil" = \''+str(round(assutUtData,2))+'\' WHERE "MachineNumber" = \''+str(machineNum)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\' AND EXTRACT(MONTH FROM "Date") = \''+str(int(i))+'\'')
                conn.execute(stringSql)

                siteIdQuery = 'SELECT Distinct("SiteId") FROM "Intellitrail_raw" WHERE "MachineNumber" = \''+str(machineNum)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\' AND EXTRACT(MONTH FROM "Date") = \''+str(int(i))+'\''
                AvgHoursCal = pd.read_sql(siteIdQuery, con=engine)

                for siteId in AvgHoursCal['SiteId']:
                    AvgQuery = ''
                    AvgQuery = 'SELECT avg("Hours") as houravgdata from "Intellitrail_raw" where "SiteId" =\''+str(siteId)+'\' AND "MachineNumber" = \''+str(machineNum)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\' AND EXTRACT(MONTH FROM "Date") = \''+str(int(i))+'\''
                    AvgHoursOutput = pd.read_sql(AvgQuery, con=engine)
                    AvgStr = ''
                    AvgStr = text('UPDATE "Intellitrail_raw" SET "hours_avg" = \''+str(round(AvgHoursOutput['houravgdata'][0],2))+'\' WHERE "SiteId" =\''+str(siteId)+'\' AND "MachineNumber" = \''+str(machineNum)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\' AND EXTRACT(MONTH FROM "Date") = \''+str(int(i))+'\'')
                    conn.execute(AvgStr)

            print "month data"



    conn.close()
    return True
    

        

