import pandas as pd
import config
from sqlalchemy import create_engine
from sqlalchemy.sql import text
import numpy as np
import calendar

'''engine = create_engine('postgresql://w08459:Div123456!@datascience-dev.cy59ywvtinrm.eu-west-1.rds.amazonaws.com:5432'
                       '/datasciencedb')'''
def file_process(event):
    '''engine = create_engine('postgresql://automation:automation@automation.cxesxp0yaizx.us-east-1.rds.amazonaws.com:5432'
                                   '/automation')'''
    engine = create_engine('%s://%s:%s@%s:%s/%s' % (config.db_driver, config.db_user, config.db_pass, config.db_host, config.db_port, config.db_name))
    conn = engine.connect()
    nulldata = 'null'
    #q = 'select "MachineNumber", "Date", "AssetUtil" From iss_usage_2012_q1 WHERE "AssetUtil" is null LIMIT 1000'
    q1 = 'SELECT Distinct(EXTRACT(YEAR FROM "Date")) as "year" FROM "Intellitrail_raw" WHERE "WeeklyAssetUtil" = \''+str(nulldata)+'\' LIMIT 1000'
    yearData = pd.read_sql(q1, con=engine)
    print "year"
    for year in yearData['year']:
        q2 = 'SELECT Distinct("MachineNumber") FROM "Intellitrail_raw" WHERE "WeeklyAssetUtil" = \''+str(nulldata)+'\' AND EXTRACT(YEAR FROM "Date") = \''+str(int(year))+'\''
        uniqueMachine = pd.read_sql(q2, con=engine)
        print "machine data"
        for machineNum in uniqueMachine['MachineNumber']:
            for i in range(1,13):
                listOfWeekDays = calendar.monthcalendar(int(year),i)
                weekCounter = 0
                for k in listOfWeekDays:
                    weekCounter = weekCounter + 1
                    dset = [j for j in k if j]
                    minVal, maxVal, countOfdaysInWeek = 0,0,0
                    minVal = min(dset)
                    maxVal = max(dset)
                    countOfdaysInWeek = len(dset)
                    minDate = str(int(year))+'-'+str(i)+'-'+str(minVal)
                    maxDate = str(int(year))+'-'+str(i)+'-'+str(maxVal)
                    q3 = 'SELECT count(Distinct("Date")) as "numberOfDaysRan" FROM "Intellitrail_raw" WHERE "MachineNumber" = \''+str(machineNum)+'\' AND "Date" between \''+minDate+'\' and \''+maxDate+'\' '
                    numberOfDaysRan = pd.read_sql(q3, con=engine)
                    assutUtData = 0
                    #number of days ran in a week
                    assutUtData = int(numberOfDaysRan['numberOfDaysRan'][0])

                    stringSql = ''
                    stringSql = text('UPDATE "Intellitrail_raw" SET "WeeklyAssetUtil" = \''+str(assutUtData)+'\' , "Weekofmonth" = \''+str(weekCounter)+'\' , "MonthOfWeek" = \''+str(minDate)+'\' WHERE "MachineNumber" = \''+str(machineNum)+'\' AND "Date" between \''+minDate+'\' and \''+maxDate+'\' ')
                    conn.execute(stringSql)
            print "month data"

    conn.close()
    return True
    

        

