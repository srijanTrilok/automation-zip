import pandas as pd
import config
from sqlalchemy import create_engine
from sqlalchemy.sql import text
import numpy as np


def file_process(event):
    engine = create_engine('%s://%s:%s@%s:%s/%s' % (config.db_driver, config.db_user, config.db_pass, config.db_host, config.db_port, config.db_name))
    #q = 'select a.*, b.*, a.machine_type as Model, b."FakeCountry" as "Country", b."SiteName1" as "SiteName" from machine_lookup a, "iss_usage_2012_q1" b where a.machine_type = b.machine_name_matched;'
    q = 'SELECT a."Date" as Rawdate, a."MonthlyAssetUtil",a."Hours" as rawhours, a."unique_key_generate", a."hours_avg", b.* FROM ("Intellitrail_raw" a LEFT JOIN tableau b ON a."FakeCountry" = b."Country" AND a."MachineNumber" = b."MachineNumber" AND a."SiteId" = b."SiteId")'
    print ("processing file")
    d = pd.read_sql(q, con=engine)
    print("readSql")
    del d['index']
    d.fillna(0)
    d['UsageMins'] = [(float(str(x).replace(',','.')) * 60) for x in d.hours_avg]
    FE = d.drop_duplicates(subset='unique_key_generate')
    stringSql = ''
    del FE['unique_key_generate']
    FE.to_sql('raw_data_ljoin_tableau', con=engine, schema='public', if_exists='replace', chunksize=1000)
    stringSql = text('DELETE FROM raw_data_ljoin_tableau WHERE "MachineNumber" is null')
    conn = engine.connect()
    conn.execute(stringSql)
    conn.close()
    print ("done")
    return True


        

