import pandas as pd
import config
from sqlalchemy import create_engine
import numpy as np

def file_process(event):
    
    engine = create_engine('%s://%s:%s@%s:%s/%s' % (config.db_driver, config.db_user, config.db_pass, config.db_host, config.db_port, config.db_name))
    #q = 'select a.*, b.*, a.machine_type as Model, b."FakeCountry" as "Country", b."SiteName1" as "SiteName" from machine_lookup a, "iss_usage_2012_q1" b where a.machine_type = b.machine_name_matched;'
    #q = 'SELECT a."Date" as Rawdate,a."WeeklyAssetUtil",a."MonthlyAssetUtil", b.*, c.* FROM ("Intellitrail_raw" a LEFT JOIN tableau_wipro b ON a."FakeCountry" = b."Country" AND a."MachineNumber" = b."MachineNumber" AND a."SiteId" = b."SiteId") LEFT JOIN machines c ON b."SiteName" = c."name" AND b."model" = c."type of machine"'
    whereCountry = "%%Norway%%"
    q = 'SELECT a."Date" as Rawdate,a."WeeklyAssetUtil",a."MonthlyAssetUtil",a."hours_avg",a."Weekofmonth",a."MonthOfWeek", b.*, c.* FROM ("machines" c LEFT JOIN tableau b ON b."SiteName" = c."name" AND b."Country" LIKE \''+whereCountry+'\') LEFT JOIN "Intellitrail_raw" a ON a."FakeCountry" = b."Country" AND a."MachineNumber" = b."MachineNumber" AND a."SiteId" = b."SiteId" ' 
    print ("processing file")
    d = pd.read_sql(q, con=engine)
    print("readSql")
    d.hours_avg = [str(x).replace('None','0') for x in d.hours_avg]
    d['UsageMins'] = [(float(str(x).replace(',','.')) * 60) for x in d.hours_avg]
    d['WeeklyComparison'] = 'null' # if avg('weekly cleaning frequency') <= max(weeklyAssetUtil) Green else Red
    d[['weekly cleaning frequency', 'calculated time machine cleaning', 'area suitable for machine cleaning', 'iss department']] = d[['weekly cleaning frequency', 'calculated time machine cleaning', 'area suitable for machine cleaning', 'iss department']].fillna(value=0)

    d['ActualCleaningTime'] = 60 * (d['area suitable for machine cleaning'].astype(float))/(d['usageMedian'].astype(float))

    d['DiffCleaning'] = (d['ActualCleaningTime'].astype(float) - d['sq_hr'].astype(float)) / d['sq_hr'].astype(float)

    d['CleaningTrafficLight'] = np.where(d['DiffCleaning'] < -0.1, 'Red', (np.where((d['DiffCleaning'] >= 0.1) & (d['DiffCleaning'] < 0.3),'Yellow', 'Green')))

    d.to_sql('tableau_norway', con=engine, schema='public', if_exists='replace', chunksize=1000)
    print ("done")
    return True

  