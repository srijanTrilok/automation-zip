
# coding: utf-8

# In[6]:


import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy import types
import numpy as np
import config

# In[2]:

def file_process(event):
    cols = ['MachineNumber', 'MachineTypDesignation', 'Date', 'Hours', 'CustomerId', 'SiteId',
            'SiteNumber', 'SiteName1', 'FakeCountry']
    ###MACHINE TYPE CLEANING
    #read all data
    raw = pd.read_csv('raw.tsv', sep='\t', error_bad_lines=False,
                      usecols = cols)


    # In[2]:


    # In[8]:
    print("read")


    # In[3]:


    def uidFixer(x):
        try:
            o = str(int(float(x)))
        except:
            o = str(x)
        return(o)

    raw['MachineNumber'] = [uidFixer(x) for x in raw.MachineNumber]
    raw['Date'] = pd.to_datetime(raw.Date)

    raw['MachineNameTemp'] = [x.lower()  for x in raw['MachineTypDesignation']]
    raw['MachineNameTemp'] = [x.replace("taski", "") for x in raw['MachineNameTemp']]
    raw['MachineNameTemp'] = [x.lstrip() for x in raw['MachineNameTemp']]
    raw['machine_name_matched'] = ''

    i = raw.loc[raw.FakeCountry=='Global'].index.tolist()
    raw.set_value(i, col='FakeCountry', value='USA')


    # In[4]:


    engine = create_engine('%s://%s:%s@%s:%s/%s' % (config.db_driver, config.db_user, config.db_pass, config.db_host, config.db_port, config.db_name))


    q = "select * from machine_lookup"
    lookup = pd.read_sql(q, con=engine)


    # In[5]:


    from numpy import argmax
    import difflib

    for index, row in raw.iterrows():
        distance = [difflib.SequenceMatcher(None, x,row.MachineNameTemp).ratio() for x in lookup.machine_type]
        if max(distance) > 0.6:
            raw.set_value(index, col='machine_name_matched', value=lookup['machine_type'][argmax(distance)])
        else:
            pass

    del raw['MachineNameTemp']


    # In[8]:
    print("insert")

    raw.to_sql('ISS_usage_2017_Jan_June', con=engine, schema='public', if_exists='replace', chunksize=1000,
               dtype={'MachineNumber':types.VARCHAR,
                      'MachineTypDesignation':types.VARCHAR,
                      'Date':types.DATE,
                      'Hours':types.FLOAT,
                      'CustomerId':types.VARCHAR,
                      'SiteId':types.VARCHAR,
                      'SiteNumber':types.VARCHAR,
                      'SiteName1':types.VARCHAR,
                      'FakeCountry':types.VARCHAR,
                      'machine_name_matched':types.VARCHAR
                      })

    '''cols_1 = ['CustomerId', 'SiteId',
            'SiteNumber', 'SiteName1', 'FakeCountry','Latitude', 'Longitude', 'SiteCity', 'Date']
    raw_1 = pd.read_csv('raw.tsv', sep='\t', error_bad_lines=False, usecols = cols_1, low_memory = False)
    raw_1['key']=raw_1.CustomerId.astype(str)+raw_1.SiteId.astype(str)+raw_1.SiteNumber.astype(str)+raw_1.SiteName1
    raw_1 = raw_1.drop_duplicates(subset='key')
    raw2 = raw_1.set_index("key")
    raw2['siteInfoDate'] = raw2['Date']
    del raw2['Date']
    raw2.to_sql('ISS_usage_Site_Info', con=engine, schema='public', if_exists='append', chunksize=1000,
               dtype={'CustomerId':types.VARCHAR,
                      'SiteId':types.VARCHAR,
                      'SiteNumber':types.VARCHAR,
                      'SiteName1':types.VARCHAR,
                      'FakeCountry':types.VARCHAR
                      })'''

