import os, sys
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/lib")

import numpy

def lambda_handler(event, context):
	print(numpy.array([1,2,3]))
	return "done"
